package com.example.project_management_portal.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.project_management_portal.model.User;
import com.example.project_management_portal.repository.RegistrationRepository;

@Service
public class RegistrationService {
	
	@Autowired
	private RegistrationRepository repo;
	
	public User saveUser(User user) {
		return repo.save(user);
	}
	
	public User fetchUserByEmailAddress(String email) {
		return repo.findByEmailAddress(email);
	}
	
	public User fetchUserByEmailAddressAndPassword(String email, String pass) {
		return repo.findByEmailAddressAndPassword(email, pass);
	}
	
	public List<User> getEmployees() {
		return (List<User>) repo.findAll();
	}
}
