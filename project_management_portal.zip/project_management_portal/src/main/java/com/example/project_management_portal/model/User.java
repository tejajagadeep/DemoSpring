package com.example.project_management_portal.model;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class User {
	
	public User() {
		super();
	}

	@Id
	private String userId;
	
	private String name;
	private String emailAddress;
	private String contactNumber;
	private String dateOfBirth;
	private String userType;
	private String password;
	
	public User(String userId, String name, String emailAddress, String contactNumber, String dateOfBirth,
			String userType, String password) {
		super();
		this.userId = userId;
		this.name = name;
		this.emailAddress = emailAddress;
		this.contactNumber = contactNumber;
		this.dateOfBirth = dateOfBirth;
		this.userType = userType;
		this.password = password;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmailAddress() {
		return emailAddress;
	}

	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}

	public String getContactNumber() {
		return contactNumber;
	}

	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}

	public String getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public String getUserType() {
		return userType;
	}

	public void setUserType(String userType) {
		this.userType = userType;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}
	
}
