package com.example.project_management_portal.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.project_management_portal.model.User;
import com.example.project_management_portal.service.RegistrationService;

@RestController
public class RegistrationController {
	
	@Autowired
	private RegistrationService service;
	
	@PostMapping("/registeruser")
	@CrossOrigin(origins = "http://localhost:4200")
	public User registerUser(@RequestBody User user) throws Exception {
		
		String tempEmailAddress = user.getEmailAddress();
		
		if (tempEmailAddress != null && !"".equals(tempEmailAddress)) {
			User userObj = service.fetchUserByEmailAddress(tempEmailAddress);
			if (userObj != null) {
				throw new Exception("User Already Exist");
			}
		}
		
		User userObj = null;
		userObj = service.saveUser(user);
		return userObj;
	}
	
	@PostMapping("/login")
	@CrossOrigin(origins = "http://localhost:4200")
	public User loginUser(@RequestBody User user) throws Exception {
		
		String tempEmailAddress = user.getEmailAddress();
		String tempPass = user.getPassword();
		User userObj = null;
		
		if (tempEmailAddress != null && tempPass != null) {
			userObj = service.fetchUserByEmailAddressAndPassword(tempEmailAddress, tempPass);
		}
		
		if (userObj == null) {
			throw new Exception("Invalid Credentials");
		}
		
		return userObj;
	}
}
