package com.example.project_management_portal.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.project_management_portal.model.User;

public interface RegistrationRepository extends JpaRepository<User, String>{
	
	public User findByEmailAddress(String emailAddress);
	public User findByEmailAddressAndPassword(String emailAddress, String password);
}
