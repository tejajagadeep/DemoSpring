package com.example.project_management_portal;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjectManagementPortalApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProjectManagementPortalApplication.class, args);
	}

}
