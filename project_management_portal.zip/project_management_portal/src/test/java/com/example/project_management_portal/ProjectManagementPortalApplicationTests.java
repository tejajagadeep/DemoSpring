package com.example.project_management_portal;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjectManagementPortalApplicationTests {

	@Test
	void contextLoads() {
	}

}
