
// Data model for Issue
export class Issue {
    title!: string;
    description!: string;
}

