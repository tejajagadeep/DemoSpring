/*

The calculateNetPayable() function should accept 3 inputs:
pricePerKilo, quantityInKilo and discountPercentage.

Calculate the net amount post discount that would be payable.

The function should return the computed value.

The function should return error message "Invalid Input Types, All Inputs Should Be of Type Number !!", 
for any non-numeric value passed to the function.

*/
function calculateNetPayable(pricePerKilo: any, quantityInKilo: any, discountPercentage: any): number | string {
    if (typeof pricePerKilo !== 'number' || typeof quantityInKilo !== 'number' || typeof discountPercentage !== 'number' ||
        isNaN(pricePerKilo) || isNaN(quantityInKilo) || isNaN(discountPercentage)) {
        return "Invalid Input Types, All Inputs Should Be of Type Number !!";
    }

    const netPayable = pricePerKilo * quantityInKilo * (1 - discountPercentage / 100);
    return netPayable;
}
