/*

The drawPattern() function should accept number of rows as input.

The function should return string that contains the pyramid structure for the number of rows inputted.

The pyramid structure should have the following pattern:

        *
       * *
      * * *
     * * * *
    * * * * *

The function should return error message "Invalid Input Type, Row Input Should Be of Type Number !!", 
if non-numeric value is passed to the function.

*/
function drawPattern(rows: any): string | string[] {
    if (typeof rows !== 'number' || isNaN(rows)) {
        return "Invalid Input Type, Row Input Should Be of Type Number !!";
    }

    const pattern: string[] = [];

    for (let i = 1; i <= rows; i++) {
        const spaces = ' '.repeat(rows - i);
        const stars = '* '.repeat(i).trim();
        pattern.push(`${spaces}${stars}`);
    }

    return pattern.join('\n');
}
