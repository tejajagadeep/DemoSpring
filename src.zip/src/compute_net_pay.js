/*

The calculateNetPayable() function should accept 3 inputs:
pricePerKilo, quantityInKilo and discountPercentage.

Calculate the net amount post discount that would be payable.

The function should return the computed value.

The function should return error message "Invalid Input Types, All Inputs Should Be of Type Number !!",
for any non-numeric value passed to the function.

*/
function calculateNetPayable(pricePerKilo, quantityInKilo, discountPercentage) {
    if (typeof pricePerKilo !== 'number' || typeof quantityInKilo !== 'number' || typeof discountPercentage !== 'number' ||
        isNaN(pricePerKilo) || isNaN(quantityInKilo) || isNaN(discountPercentage)) {
        return "Invalid Input Types, All Inputs Should Be of Type Number !!";
    }
    var netPayable = pricePerKilo * quantityInKilo * (1 - discountPercentage / 100);
    return netPayable;
}
// Example usage:
var pricePerKilo = 10;
var quantityInKilo = 5;
var discountPercentage = 10;
var result = calculateNetPayable(pricePerKilo, quantityInKilo, discountPercentage);
if (typeof result === 'number') {
    console.log("Net Payable Amount: $".concat(result));
}
else {
    console.log(result);
}
