package com.stackroute.swaggerautoconfbean;


import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SwaggerAutoConfBeanApplication {

	public static void main(String[] args) {
		SpringApplication.run(SwaggerAutoConfBeanApplication.class, args);
	}

}
