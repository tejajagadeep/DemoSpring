package com.stackroute.swaggerautoconfbean.config;



//implement DataSource interface in CustomDataSource Class to override the methods
public class CustomDataSource  {
    //Override the DataSource interface methods

}
