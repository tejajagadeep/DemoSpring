package com.cts.projectmanagementportalbackend.configuration;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class UserSecurityTest {

	@Test
	void testHasUserName() {
//		fail("Not yet implemented");
	}

}
