
import edu.princeton.cs.algs4.StdIn;
import edu.princeton.cs.algs4.StdRandom;
import edu.princeton.cs.algs4.StdOut;

public class RandomWord {
    public static void main(String[] args) {
        String c = "";
        int i =1;
        while (!StdIn.isEmpty()) {
            String word = StdIn.readString();
            if(StdRandom.bernoulli(1.0/i)) {
                c = word;
            }
            i++;

        }
            StdOut.println(c);

    }

}
