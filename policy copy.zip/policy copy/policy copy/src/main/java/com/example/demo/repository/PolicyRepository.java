package com.example.demo.repository;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.example.demo.entity.Policy;

public interface PolicyRepository extends MongoRepository<Policy, String> {

}
