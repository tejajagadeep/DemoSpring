package com.example.demo.entity;

import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection="SearchPolicy")
public class SearchPolicy {
	
	public Long numberofYears;
	public String companyName;
	public String policyType;
	public Long policyId;
	public String policyName;
	public Long getNumberofYears() {
		return numberofYears;
	}
	public void setNumberofYears(Long numberofYears) {
		this.numberofYears = numberofYears;
	}
	public String getCompanyName() {
		return companyName;
	}
	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}
	public String getPolicyType() {
		return policyType;
	}
	public void setPolicyType(String policyType) {
		this.policyType = policyType;
	}
	public Long getPolicyId() {
		return policyId;
	}
	public void setPolicyId(Long policyId) {
		this.policyId = policyId;
	}
	public String getPolicyName() {
		return policyName;
	}
	public void setPolicyName(String policyName) {
		this.policyName = policyName;
	}
	

}
