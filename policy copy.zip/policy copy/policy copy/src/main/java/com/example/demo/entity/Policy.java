package com.example.demo.entity;

import java.util.Date;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import com.mongodb.lang.NonNull;

@Document(collection="PolicyRegistration")
public class Policy {
	
	@Id
	public String policyId;
	@NonNull
	public String policyName;
	@NonNull
	public Date startDate;
	@NonNull
	public Long duration;
	@NonNull
	public String companyName;
	@NonNull
	public Long initialDeposit;
	@NonNull
	public String policyType;
	@NonNull
	public String userType;
	@NonNull
	public Long termsPerYear;
	@NonNull
	public Long termAmount;
	@NonNull
	public Long interestRate;
	
	public String getPolicyId() {
		return policyId;
	}
	public void setPolicyId(String policyId) {
		policyId = policyId;
	}
	
	public String getPolicyName() {
		return policyName;
	}
	public void setPolicyName(String policyName) {
		this.policyName = policyName;
	}
	public Date getStartDate() {
		return startDate;
	}
	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}
	public Long getDuration() {
		return duration;
	}
	public void setDuration(Long duration) {
		this.duration = duration;
	}
	public String getCompanyName() {
		return companyName;
	}
	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}
	public Long getInitialDeposit() {
		return initialDeposit;
	}
	public void setInitialDeposit(Long initialDeposit) {
		this.initialDeposit = initialDeposit;
	}
	public String getPolicyType() {
		return policyType;
	}
	public void setPolicyType(String policyType) {
		this.policyType = policyType;
	}
	public String getUserType() {
		return userType;
	}
	public void setUserType(String userType) {
		this.userType = userType;
	}
	public Long getTermsPerYear() {
		return termsPerYear;
	}
	public void setTermsPerYear(Long termsPerYear) {
		this.termsPerYear = termsPerYear;
	}
	public Long getTermAmount() {
		return termAmount;
	}
	public void setTermAmount(Long termAmount) {
		this.termAmount = termAmount;
	}
	public Long getInterestRate() {
		return interestRate;
	}
	public void setInterestRate(Long interestRate) {
		this.interestRate = interestRate;
	}
	

}
