package com.example.demo.service;

import org.springframework.beans.factory.annotation.Autowired;

import com.example.demo.entity.Customer;
import com.example.demo.repository.CustomerRepository;

public interface CustomerService {

	Customer registerCustomer(Customer customer);

	
}
